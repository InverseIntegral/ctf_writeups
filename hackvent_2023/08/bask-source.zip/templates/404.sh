#!/bin/bash

# Include header
bash templates/header.sh
cat << EOF
<main role="main" class="inner cover">
    <h1>404 not found</h1>
</main>
EOF
# Include footer
bash templates/footer.sh
