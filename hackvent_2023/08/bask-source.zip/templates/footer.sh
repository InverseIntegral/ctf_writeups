#!/bin/bash
cat << EOF
    <footer class="mastfoot mt-auto">
        <div class="inner">
          <p>Sample page for <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ">Bask</a>, by <a href="https://twitter.com/hackvent">@Santa Claus</a>.</p>
        </div>
      </footer>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  </body>
</html>
EOF
