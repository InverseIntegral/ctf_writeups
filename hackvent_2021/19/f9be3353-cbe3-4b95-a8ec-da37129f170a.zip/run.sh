#!/bin/sh
qemu-system-i386 -m 1 -device VGA,vgamem_mb=4 -fda fda.img -fdb fdb.img